defmodule Proj4BonusTest do
  use ExUnit.Case
  doctest Proj4Bonus

  test "User recieves messages only when it's live" do
    name1 = "isabel"
    name2 = "anshika"
    sleep_id = :"#{name1}"
    # User isabel disconnectiong with empty feed 
    feed = Sleep_wake.sleep(sleep_id)

    assert feed == []

    # User anshika sends a tweet while the subscreibed follower isabel is not live
    tweet = "Hi isabel"
    new_tweets = Tweet.send_tweet(name2, tweet)

    # Isabel is live again and still has empty feed 
    feed = Sleep_wake.wake(sleep_id)

    assert feed == []
  end
end
