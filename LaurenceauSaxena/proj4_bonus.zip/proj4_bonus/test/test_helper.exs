ExUnit.start()

# Start the supervisor
DySupervisor.start_link(1)
# Start the engine
tweets = []
followers = []
subscribed = []
feed = []
{:ok, _pid} = Engine.start_link([followers, subscribed, feed, tweets, Engine])

# make(three(users))
Register.reg("isabel", "p")
Register.reg("anshika", "p")

# subscribe isabel to anshika
pid_sender1 = :"#{"isabel"}"
GenServer.call(pid_sender1, {:subscribe, "anshika"})
